#!/bin/bash

# Wallet addresses
wallets=(
    "1E8bZc5wVior9ZrmBySJwYwL6obRj4zUyz"
    "15MFgoxcBXvZrjrJb8AK7as7zf8wvznk3P"
    "1AKBZS7ZwwPCK8bS4jtevLDF6ef1JaPh3Y"
    "18w365NgFxrrJxWvN2VySbcQaTpCY2H2Kz"
    "1EX2rzqGWg29wM9fGXqSYF6PeKctcGUYCC"
)

# Function to check balances
check_balances() {
    echo "Checking balances..."
    for wallet in "${wallets[@]}"; do
        balance=$(sallmon-wallet check-balance --address "$wallet")
        echo "Balance for $wallet: $balance"
    done
}

# Function to send coins
send_coins() {
    echo "Sending coins between wallets..."
    for i in "${!wallets[@]}"; do
        sender=${wallets[$i]}
        recipient=${wallets[$(( (i + 1) % ${#wallets[@]} ))]} # Next wallet in the list
        amount=10

        echo "Sending $amount from $sender to $recipient..."
        sallmon-wallet add-utxo --address "$recipient" --tx-id "tx$RANDOM" --index 0 --amount "$amount"
    done
}

# Main process
echo "Starting balance and transfer script..."
check_balances
send_coins
echo "Re-checking balances..."
check_balances
echo "Script completed!"
