# config.py
import os

# Expand the ~ to the full home directory path
DB_PATH = os.path.expanduser("~/.sallmon/blockchain.db")
