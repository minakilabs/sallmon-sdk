import os
import json
import base64
import logging
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("wallet_utils")

# Generate RSA Key Pair
def generate_keypair():
    logger.info("Generating RSA key pair...")
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    public_key = private_key.public_key()
    logger.info("RSA key pair generated successfully.")
    return private_key, public_key

# Encrypt Data
def encrypt_data(data, password):
    logger.info("Encrypting data...")
    salt = os.urandom(16)
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    key = kdf.derive(password.encode())
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(key), modes.CFB(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    encrypted_data = encryptor.update(data) + encryptor.finalize()
    logger.info("Data encrypted successfully.")
    return base64.b64encode(salt + iv + encrypted_data).decode()

# Decrypt Data
def decrypt_data(encrypted_data, password):
    logger.info("Decrypting data...")
    decoded_data = base64.b64decode(encrypted_data)
    salt, iv, ciphertext = decoded_data[:16], decoded_data[16:32], decoded_data[32:]
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    key = kdf.derive(password.encode())
    cipher = Cipher(algorithms.AES(key), modes.CFB(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    decrypted_data = decryptor.update(ciphertext) + decryptor.finalize()
    logger.info("Data decrypted successfully.")
    return decrypted_data

# Save Wallet
def save_wallet(private_key, password, filename="wallet.json"):
    logger.info("Saving wallet...")
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    encrypted_pem = encrypt_data(pem, password)
    wallet_data = {"encrypted_key": encrypted_pem}
    with open(filename, "w") as file:
        json.dump(wallet_data, file)
    logger.info(f"Wallet saved to {filename}.")

# Load Wallet
def load_wallet(password, filename=None):
    logger.info("Loading wallet...")
    if filename is None:
        filename = os.path.expanduser("~/.sallmon-wallet/wallet.json")
    if not os.path.exists(filename):
        logger.error("Wallet file not found!")
        raise FileNotFoundError("Wallet not found!")
    with open(filename, "r") as file:
        wallet_data = json.load(file)
    encrypted_key = wallet_data["encrypted_key"]
    pem = decrypt_data(encrypted_key, password)
    logger.debug(f"Decrypted PEM: {pem.decode()}")
    private_key = serialization.load_pem_private_key(pem, password=None, backend=default_backend())
    logger.info("Wallet loaded successfully.")
    return private_key

# Generate Wallet Address
def generate_address(public_key):
    logger.info("Generating wallet address...")
    public_key_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    digest = hashes.Hash(hashes.SHA256(), backend=default_backend())
    digest.update(public_key_bytes)
    address = digest.finalize().hex()[:40]
    logger.info(f"Generated wallet address: {address}")
    return address
