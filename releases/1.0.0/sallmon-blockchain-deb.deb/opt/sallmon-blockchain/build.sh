bash build_deb.sh && bash install.sh && sudo systemctl restart sallmon-blockchain.service 
