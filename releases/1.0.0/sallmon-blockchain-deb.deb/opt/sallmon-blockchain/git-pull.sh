git reset --hard
git pull

bash build.sh
