#!/bin/bash

set -e  # Exit immediately if a command exits with a non-zero status

# Package variables
PKG_NAME="sallmon-blockchain"
PKG_VERSION="1.0.0"
ARCH="all"
DESCRIPTION="Sallmon Blockchain FastAPI server for managing transactions and mining."
MAINTAINER="Your Name <your.email@example.com>"
DEPENDS="python3, python3-pip, uvicorn"
BUILD_DIR="./${PKG_NAME}-deb"
INSTALL_DIR="/opt/${PKG_NAME}"
BIN_PATH="/usr/local/bin"

# Create the package structure
echo "Setting up package directory structure..."
rm -rf ${BUILD_DIR}  # Ensure a clean build
mkdir -p ${BUILD_DIR}/DEBIAN
mkdir -p ${BUILD_DIR}${INSTALL_DIR}
mkdir -p ${BUILD_DIR}/etc/systemd/system

# Create the control file
echo "Creating DEBIAN/control file..."
cat <<EOF > ${BUILD_DIR}/DEBIAN/control
Package: ${PKG_NAME}
Version: ${PKG_VERSION}
Section: utils
Priority: optional
Architecture: ${ARCH}
Depends: ${DEPENDS}
Maintainer: ${MAINTAINER}
Description: ${DESCRIPTION}
 A FastAPI-based blockchain server for managing transactions and mining blocks.
EOF

# Copy project files
echo "Copying project files..."
rsync -av --exclude="${BUILD_DIR}" . ${BUILD_DIR}${INSTALL_DIR}/

# Create systemd service file
echo "Creating systemd service file..."
cat <<EOF > ${BUILD_DIR}/etc/systemd/system/${PKG_NAME}.service
[Unit]
Description=Sallmon Blockchain FastAPI Server
After=network.target

[Service]
User=$(whoami)
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/python3 -m uvicorn server:app --host 0.0.0.0 --port 1337
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# Build the .deb package
echo "Building the .deb package..."
dpkg-deb --build ${BUILD_DIR}

# Output the result
echo "Package built successfully: ${BUILD_DIR}.deb"
