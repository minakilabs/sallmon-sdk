#!/bin/bash

set -e  # Exit immediately if a command exits with a non-zero status.

# Default version file
VERSION_FILE="VERSION"
START_VERSION="1.0.1"

# Ensure the VERSION file exists or initialize it
if [[ ! -f $VERSION_FILE ]]; then
    echo "Initializing version file with $START_VERSION"
    echo $START_VERSION > $VERSION_FILE
fi

# Read the current version
CURRENT_VERSION=$(cat $VERSION_FILE)
IFS='.' read -r -a VERSION_PARTS <<< "$CURRENT_VERSION"

# Increment version based on the argument
INCREMENT=${1:-"patch"}

case $INCREMENT in
    major)
        VERSION_PARTS[0]=$((VERSION_PARTS[0] + 1))
        VERSION_PARTS[1]=0
        VERSION_PARTS[2]=0
        ;;
    minor)
        VERSION_PARTS[1]=$((VERSION_PARTS[1] + 1))
        VERSION_PARTS[2]=0
        ;;
    patch)
        VERSION_PARTS[2]=$((VERSION_PARTS[2] + 1))
        ;;
    *)
        echo "Invalid argument: $INCREMENT"
        echo "Usage: $0 [major|minor|patch]"
        exit 1
        ;;
esac

# Construct the new version
NEW_VERSION="${VERSION_PARTS[0]}.${VERSION_PARTS[1]}.${VERSION_PARTS[2]}"

# Update the VERSION file
echo $NEW_VERSION > $VERSION_FILE

# Stage changes, commit, and push
git add .
git commit -m "sallmon-core-${NEW_VERSION}"
git push

# Print the new version
echo "Updated to version $NEW_VERSION"
