sudo journalctl -u sallmon-blockchain.service -n 50 -f
