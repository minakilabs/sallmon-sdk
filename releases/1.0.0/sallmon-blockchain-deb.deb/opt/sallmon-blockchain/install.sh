sudo dpkg -i sallmon-blockchain-deb.deb
sudo systemctl daemon-reload
